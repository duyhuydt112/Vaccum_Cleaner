import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, LogInfo, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
Map = 'mymap'

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    use_ros2_control = 'false'
    world_file_name = 'worlds/' + Map + '.model'
    world = os.path.join(get_package_share_directory('phatbot'), world_file_name)
    launch_file_dir = os.path.join(get_package_share_directory('phatbot'), 'launch')

    # Gazebo_ROS directory
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    print(f"use_ros2_control: {use_ros2_control}")


    #action
    gzserver_launch = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
        ),
        launch_arguments={'world': world}.items(),
        )
    
    gzclient_launch =  IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
            ),
        )
    
    robot_state_publisher_launch = IncludeLaunchDescription(
            PythonLaunchDescriptionSource([launch_file_dir, '/robot_state_publisher.launch.py']),
            launch_arguments={'use_sim_time': use_sim_time, 'use_ros2_control': use_ros2_control}.items(),
        )
    
    spawn_entity = Node(package='gazebo_ros', executable='spawn_entity.py', 
                        arguments=['-topic', 'robot_description', '-entity', 'my_bot'], output='screen')
    
    diff_drive_spawner = Node(
    package="controller_manager",
    executable="spawner.py",
    arguments=["diff_cont"],
    )

    joint_broad_spawner = Node(
    package="controller_manager",
    executable="spawner.py",
    arguments=["joint_broad"],
    )


    launch_actions = [
        gzserver_launch,
        gzclient_launch,
        robot_state_publisher_launch,
        spawn_entity,
    ]

    if use_ros2_control == 'true':
        # print(f"use_ros2_control: {use_ros2_control}")

        launch_actions.append(diff_drive_spawner)
        launch_actions.append(joint_broad_spawner)


    # Launch
    return LaunchDescription(launch_actions)
        

       

        #  TimerAction(
        #     period=5.0,  # Đợi 5 giây trước khi spawn entity
        #     actions=[spawn_entity]
        # ),

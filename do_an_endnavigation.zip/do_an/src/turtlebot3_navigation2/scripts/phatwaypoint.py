#! /usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.node import Node
from rclpy.duration import Duration

# Tạo waypoint
waypoint = PoseStamped()
waypoint.header.frame_id = 'map'
waypoint.pose.position.x = 0.5
waypoint.pose.position.y = 0.5
waypoint.pose.orientation.w = 1.0  # Hướng 0 độ

class WayPointActionClient(Node):

    def __init__(self):
        super().__init__('WayPoint_Action_Client')
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.last_feedback_time = self.get_clock().now()

    def send_waypoint(self, waypoint):
        # Tạo đối tượng goal cho waypoint
        goal = NavigateToPose.Goal()
        goal.pose = waypoint
        # Gửi goal và chờ kết quả
        self.result = self._action_client.send_goal_async(goal, feedback_callback=self.feedback_callback)
        self.result.add_done_callback(self.result_response_callback)

    def result_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
                self.get_logger().info('Goal rejected :(')
                return
        self.get_logger().info('Goal accepted :)')

        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Result: Goal reached ')
        rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        # Lấy tọa độ hiện tại của robot từ feedback
        current_position = feedback.current_pose.pose.position
        current_orientation = feedback.current_pose.pose.orientation
           # Lấy thời gian hiện tại
        current_time = self.get_clock().now()

        # Kiểm tra xem đã đủ 0.3 giây kể từ lần in feedback trước
        if (current_time - self.last_feedback_time) > Duration(seconds=0.3):
            self.get_logger().info(f"Feedback: Current position - X: {current_position.x}, Y: {current_position.y}, W: {current_orientation.w}")
            # Cập nhật thời gian feedback vừa in ra
            self.last_feedback_time = current_time

def main(args=None):
    rclpy.init(args=args)
    # Tạo một client Action cho hành động NavigateToPose
    action_client = WayPointActionClient()

    # Đảm bảo action client đã sẵn sàng
    if not action_client._action_client.wait_for_server(timeout_sec=10.0):
        action_client.get_logger().error('Không thể kết nối tới server')
        return

    # Gửi waypoint vào action server và chờ kết quả
    
    action_client.send_waypoint(waypoint)

    # Chờ và nhận kết quả
    rclpy.spin(action_client)

    # rclpy.shutdown()

if __name__ == '__main__':
    main()

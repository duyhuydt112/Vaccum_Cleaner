#! /usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

def send_waypoint(client, waypoint):
    # Tạo đối tượng goal cho waypoint
    goal = NavigateToPose.Goal()
    goal.pose = waypoint
    # Gửi goal và chờ kết quả
    return client.send_goal_async(goal)

def feedback_callback(feedback):
    # Hàm callback để nhận phản hồi trong quá trình điều hướng
    print(f"Feedback: Current position: {feedback.feedback.current_pose.pose.position.x}, {feedback.feedback.current_pose.pose.position.y}")

def main(args=None):
    rclpy.init(args=args)

    # Tạo một client Action cho hành động NavigateToPose
    node = rclpy.create_node('send_waypoints_node')
    action_client = ActionClient(node, NavigateToPose, 'navigate_to_pose')

    # Đảm bảo action client đã sẵn sàng
    if not action_client.wait_for_server(timeout_sec=10.0):
        node.get_logger().error('Không thể kết nối tới server')
        return

    # Tạo waypoint
    waypoint = PoseStamped()
    waypoint.header.frame_id = 'map'
    waypoint.pose.position.x = 1.0
    waypoint.pose.position.y = 1.0
    waypoint.pose.orientation.w = 1.0  # Hướng 0 độ

    # Gửi waypoint vào action server và chờ kết quả
    future = send_waypoint(action_client, waypoint)

    # Đăng ký hàm callback để nhận phản hồi
    def handle_result(fut):
        goal_handle = fut.result()
        goal_handle.feedback_callback = feedback_callback

    future.add_done_callback(handle_result)

    # Chờ và nhận kết quả
    rclpy.spin(node)

    rclpy.shutdown()

if __name__ == '__main__':
    main()

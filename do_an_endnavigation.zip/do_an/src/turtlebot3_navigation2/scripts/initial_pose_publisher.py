#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
import yaml

class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__('initial_pose_publisher')
        self.publisher_ = self.create_publisher(PoseWithCovarianceStamped, '/initialpose', 10)
        self.get_logger().info("Publishing initial pose")
        
        # Đọc tệp YAML
        with open('/home/phat/do_an/src/turtlebot3_navigation2/param/InitialPose.yaml', 'r') as file:
            self.initial_pose_data = yaml.safe_load(file)
        
        # Xuất bản vị trí ban đầu một lần
        self.publish_initial_pose()
        self.get_logger().info("Initial pose published successfully.")
        
    def publish_initial_pose(self):
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = self.initial_pose_data['header']['frame_id']
        msg.pose.pose.position.x = self.initial_pose_data['pose']['pose']['position']['x']
        msg.pose.pose.position.y = self.initial_pose_data['pose']['pose']['position']['y']
        msg.pose.pose.position.z = self.initial_pose_data['pose']['pose']['position']['z']
        msg.pose.pose.orientation.z = self.initial_pose_data['pose']['pose']['orientation']['z']
        msg.pose.pose.orientation.w = self.initial_pose_data['pose']['pose']['orientation']['w']
        msg.pose.covariance = self.initial_pose_data['pose']['covariance']
        
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = InitialPosePublisher()
    rclpy.spin(node)  # Chờ node hoạt động
    rclpy.shutdown()  # Dừng ROS sau khi spin kết thúc

if __name__ == '__main__':
    main()

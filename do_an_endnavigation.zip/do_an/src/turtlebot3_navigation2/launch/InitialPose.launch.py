from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlebot3_navigation2',
            executable='initial_pose_publisher.py',
            name='initial_pose_publisher',
            output='screen'
        )
    ])

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlebot3_navigation2',
            executable='phatwaypoint.py',
            name='Phat_waypoint_Publisher',
            output='screen'
        )
    ])
